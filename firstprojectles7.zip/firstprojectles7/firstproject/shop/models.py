from django.db import models

# Create your models here.
def type():
    category = [
        ('dresses', 'сукні'),
        ('suits', 'костюми'),
        ('bags', 'сумки')
    ]
    return category
class Shoping(models.Model):
    name = models.CharField(max_length=40)
    file = models.FileField()
    price = models.CharField(max_length=30)
    way = models.URLField()
    type = models.CharField(max_length=10, choices=type(), default='')

    def __str__(self):
        return self.name
