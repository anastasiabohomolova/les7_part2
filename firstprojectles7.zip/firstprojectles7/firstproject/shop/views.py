from django.shortcuts import render
from django.http import HttpResponse
from shop.models import Shoping
# Create your views here.
def func_shop(request):
    return HttpResponse('<h1>page shop</h1>')

def shop_dresses(request):
    queryset = Shoping.objects.filter(type='dresses')
    context = {
        'title': 'Dresses',
        'objects_list': queryset
    }

    return render(request, 'shop.html', context)

def shop_suits(request):
    queryset = Shoping.objects.filter(type='suits')
    context = {
        'title': 'Suits',
        'objects_list': queryset
    }

    return render(request, 'shop.html', context)

def shop_bags(request):
    queryset = Shoping.objects.all()
    context = {
        'title': 'Bags',
        'objects_list': queryset.filter(type='bags')
    }

    return render(request, 'shop.html', context)



