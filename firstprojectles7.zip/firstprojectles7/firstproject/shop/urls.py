from django.urls import path
from shop.views import func_shop, shop_dresses, shop_suits, shop_bags


urlpatterns = [
    path('', func_shop),
    path('dresses/', shop_dresses),
    path('suits/', shop_suits),
    path('bags/', shop_bags)
]